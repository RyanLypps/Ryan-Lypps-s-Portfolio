require("babel-register");
