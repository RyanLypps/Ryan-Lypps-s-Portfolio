# tic-tac-toe

An interactive tic-tac-toe game.

## Setup

```
npm install
```
```
npm run build
```
```
npm start
```

## Contributing

* Please follow the AirBnB styleguide.

* Open a pull request, all contributions will be considered.
